public class Car {

        static int numberOfTotalCars = 0;

        String color;
        String brand;
        int numberOfWheels;
        boolean isFast;

        public Car(){
            System.out.println("Car is created!");
            numberOfTotalCars++;
        }
        public void letsDrive(){

            System.out.println("Now driving");
        }
        public void carIsSold(){
            System.out.println(brand + " just sold!");
        }

        public Car(String colorOfThecar, String brandOfTheCar, int numberOfWheelsThatWeHave, boolean isCarFast){
            color = colorOfThecar;
            brand = brandOfTheCar;
            numberOfWheels = numberOfWheelsThatWeHave;
            isFast = isCarFast;
       }

}
